"""绿金街供应链项目管理平台 - 路演启动器（双击 _一键启动.bat 由它接管）"""
import os
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser

ROOT = os.path.dirname(os.path.abspath(__file__))
PORT = 8927
URL = f"http://127.0.0.1:{PORT}"

ACCOUNTS = [
    ("lijuanyan", "业务员（主演示）"),
    ("buzhang", "业务部经理"),
    ("zongjingli", "总经理"),
    ("caiwu", "财务专员"),
    ("caiwuzhuguan", "财务主管"),
]


def say(msg=""):
    print(msg, flush=True)


def banner():
    say("=" * 46)
    say("   绿金街供应链项目管理平台")
    say("=" * 46)
    say()


def check_python():
    v = sys.version_info
    if (v.major, v.minor) < (3, 10):
        say(f"[错误] 需要 Python 3.10 以上，当前 {v.major}.{v.minor}")
        return False
    say(f"[1/4] Python {v.major}.{v.minor}.{v.micro}   {sys.executable}")
    return True


def check_deps():
    missing_hard, missing_soft = [], []
    for mod, desc, hard in [
        ("openpyxl", "读取台账与资金占用费表", True),
        ("fitz", "PDF 文字提取", False),
        ("pypdf", "PDF 回单文字提取", False),
        ("rapidocr_onnxruntime", "扫描件 OCR", False),
        ("docx", "催款函 Word 生成", False),
    ]:
        try:
            __import__(mod)
        except Exception:
            (missing_hard if hard else missing_soft).append((mod, desc))
    if missing_hard:
        say("[2/4] [错误] 缺少核心依赖：" + "、".join(d for _, d in missing_hard))
        say("      请联网后执行：")
        say(f"      {sys.executable} -m pip install -r work_review\\requirements.txt")
        return False
    if missing_soft:
        say(f"[2/4] 核心依赖 OK；{len(missing_soft)} 项可选组件缺失（不影响主线演示）：")
        for _, desc in missing_soft:
            say(f"      - {desc}")
    else:
        say("[2/4] 依赖全部就绪")
    return True


def port_busy(port):
    with socket.socket() as s:
        s.settimeout(1)
        return s.connect_ex(("127.0.0.1", port)) == 0


def kill_old(port):
    """端口被占时，尽量收掉旧实例（旧实例跑的是旧代码）。"""
    try:
        out = subprocess.run(
            ["netstat", "-ano", "-p", "TCP"], capture_output=True, text=True, errors="ignore"
        ).stdout
    except Exception:
        return
    pids = set()
    for line in out.splitlines():
        parts = line.split()
        if len(parts) >= 5 and parts[1].endswith(f":{port}") and parts[3] == "LISTENING":
            pids.add(parts[4])
    for pid in pids:
        if pid.isdigit():
            subprocess.run(["taskkill", "/PID", pid, "/F"], capture_output=True)
            say(f"      已停止旧实例 PID={pid}")


def launch():
    env = dict(os.environ)
    env["PORT"] = str(PORT)
    env["PYTHONUNBUFFERED"] = "1"
    env["DATASET_ROOT"] = os.path.join(ROOT, "A项目-演示资料")
    env.setdefault("MODEL_PROVIDER", "deepseek" if env.get("DEEPSEEK_API_KEY") else "ollama")
    log_path = os.path.join(ROOT, "_server.log")
    log = open(log_path, "w", encoding="utf-8", errors="replace")
    flags = 0
    if os.name == "nt":
        # 路演时桌面要干净：服务进程不要弹黑窗口，日志写到 _server.log。
        # 之前用 CREATE_NEW_CONSOLE 会多一个可见控制台，投影时碍事。
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    proc = subprocess.Popen(
        [sys.executable, os.path.join("work_review", "server.py")],
        cwd=ROOT,
        env=env,
        stdout=log,
        stderr=subprocess.STDOUT,
        creationflags=flags,
    )
    return proc, log_path


def wait_ready(proc, timeout=90):
    for i in range(timeout):
        time.sleep(1)
        if proc.poll() is not None:
            return False, f"服务进程退出了（退出码 {proc.returncode}）"
        try:
            urllib.request.urlopen(URL + "/", timeout=3).read(64)
            return True, f"{i + 1}s"
        except Exception:
            pass
    return False, f"{timeout}s 内无响应"


def main():
    banner()
    if not check_python():
        input("按回车退出...")
        return 1
    if not check_deps():
        input("按回车退出...")
        return 1
    if not os.path.isfile(os.path.join(ROOT, "work_review", "server.py")):
        say("[错误] 找不到 work_review\\server.py，请确认文件和文件夹在同一目录")
        input("按回车退出...")
        return 1

    if port_busy(PORT):
        say(f"[3/4] 端口 {PORT} 被占用，正在替换为新实例 ...")
        kill_old(PORT)
        time.sleep(2)
    else:
        say(f"[3/4] 端口 {PORT} 空闲")

    say("[4/4] 启动服务并等待就绪 ...")
    proc, log_path = launch()
    ok, info = wait_ready(proc)
    if not ok:
        say()
        say(f"[失败] {info}")
        say(f"       详细日志：{log_path}")
        say("       把 _server.log 最后 20 行截图给技术人员即可。")
        input("按回车退出...")
        return 1

    say()
    say("=" * 46)
    say(f"   启动成功（{info}）")
    say("=" * 46)
    say()
    say(f"   浏览器地址：{URL}")
    say()
    say("   演示账号（密码统一 88888888）：")
    for u, role in ACCOUNTS:
        say(f"     {u:<14}{role}")
    say()
    say("   服务已在后台运行（没有黑窗口，投影桌面是干净的）。")
    say("   演示结束要停止服务，双击 _停止服务.bat。")
    say("   本窗口可以直接关掉，服务不受影响。")
    say()
    try:
        webbrowser.open(URL)
    except Exception:
        pass
    time.sleep(3)
    return 0


if __name__ == "__main__":
    sys.exit(main())
