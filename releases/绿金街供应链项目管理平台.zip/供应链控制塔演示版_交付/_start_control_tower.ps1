﻿$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Port = 8927

Write-Host ''
Write-Host '========================================' -ForegroundColor Cyan
Write-Host '   供应链控制塔演示版 - 一键启动' -ForegroundColor Cyan
Write-Host '========================================' -ForegroundColor Cyan
Write-Host ''

# ---------- 1. 找 Python 解释器（不依赖用户名和固定安装路径） ----------
$py = $null
$pyArgs = @()
if ($env:PORTABLE_PYTHON -and (Test-Path -LiteralPath $env:PORTABLE_PYTHON)) {
    $py = $env:PORTABLE_PYTHON
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
    foreach ($version in @('3.12', '3.11', '3.10')) {
        try {
            $candidate = (& py "-$version" -c 'import sys; print(sys.executable)' 2>$null).Trim()
            if ($candidate -and (Test-Path -LiteralPath $candidate)) { $py = 'py'; $pyArgs = @("-$version"); break }
        } catch { }
    }
}
if (-not $py -and (Get-Command python -ErrorAction SilentlyContinue)) { $py = 'python' }
if (-not $py) {
    Write-Host '[错误] 没有找到 Python 3.10 或更高版本。' -ForegroundColor Red
    Write-Host '需要先安装 Python 3.12：https://www.python.org/downloads/，安装时勾选 Add Python to PATH' -ForegroundColor Yellow
    Read-Host '按回车键退出'; exit 1
}
# 注意：这里的 python 单行命令不能含双引号。Windows PowerShell 5.1 在向
# 原生程序传参时会破坏内嵌双引号，导致 python 收到残缺代码而报语法错。
$eapSaved = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$versionText = (& $py @pyArgs -c 'import sys; print(sys.version.split()[0])' 2>&1 | Select-Object -First 1)
$ErrorActionPreference = $eapSaved
if ($versionText) { $versionText = $versionText.ToString().Trim() }
if (-not $versionText) { $versionText = '未知' }
$versionParts = $versionText.Split('.')
$majorOk = $versionParts.Count -ge 2 -and [int]$versionParts[0] -ge 3 -and ([int]$versionParts[0] -gt 3 -or [int]$versionParts[1] -ge 10)
if (-not $majorOk) {
    Write-Host "[错误] 需要 Python 3.10 或更高版本，当前为：$versionText" -ForegroundColor Red
    Write-Host '       请到 https://www.python.org/downloads/ 安装 Python 3.12，安装时勾选 Add Python to PATH' -ForegroundColor Yellow
    Read-Host '按回车键退出'; exit 1
}
if ([int]$versionParts[1] -ge 13) {
    Write-Host "[提示] 检测到 Python $versionText；本交付包已按 Python 3.12 验证，建议使用 Python 3.12。" -ForegroundColor Yellow
    Write-Host '       当前版本仍可继续启动；个别可选组件可能存在版本兼容差异。' -ForegroundColor DarkGray
}
Write-Host "[1/5] 解释器  $py $($pyArgs -join ' ') (Python $versionText)" -ForegroundColor DarkGray

if (-not (Test-Path -LiteralPath (Join-Path $Root 'work_review\server.py'))) {
    Write-Host "[错误] 找不到项目文件：$Root\work_review\server.py" -ForegroundColor Red
    Write-Host ''
    Read-Host '按回车键退出'
    exit 1
}

# ---------- 2. API Key（允许无 Key 降级启动） ----------
$key = [Environment]::GetEnvironmentVariable('DEEPSEEK_API_KEY', 'User')
if ([string]::IsNullOrWhiteSpace($key)) {
    Write-Host ''
    Write-Host '[2/5] 首次运行，需要设置 DeepSeek API Key' -ForegroundColor Yellow
    Write-Host '      Key 获取地址: https://platform.deepseek.com/api_keys' -ForegroundColor DarkGray
    Write-Host '      一般是 sk- 开头的一长串字符。输入后只保存这一步，以后不再问。' -ForegroundColor DarkGray
    Write-Host ''
    $key = (Read-Host '      请粘贴 API Key（直接回车可无 Key 启动）').Trim()
    if ([string]::IsNullOrWhiteSpace($key) -or $key -eq 'skip') {
        $key = ''
        Write-Host '      未配置 DeepSeek Key，智能问答将降级；看板/OCR/新增项目/结算核算不受影响。' -ForegroundColor Yellow
    } else {
        try { [Environment]::SetEnvironmentVariable('DEEPSEEK_API_KEY', $key, 'User') } catch { Write-Host '      当前用户环境变量不可写，本次启动仍会使用该 Key。' -ForegroundColor Yellow }
        $mask = $key.Substring(0, [Math]::Min(6, $key.Length)) + '****' + $key.Substring([Math]::Max(0, $key.Length - 4))
        Write-Host "      已保存到用户环境变量 ($mask)" -ForegroundColor Green
    }
} else {
    $mask = $key.Substring(0, [Math]::Min(6, $key.Length)) + '****' + $key.Substring([Math]::Max(0, $key.Length - 4))
    Write-Host "[2/5] API Key 已保存 ( $mask )" -ForegroundColor Green
}

# ---------- 2.5 首次运行自动检查依赖（硬/软两档） ----------
# openpyxl 缺失时无法读取台账，必须明确提示并退出；PDF/OCR/Word
# 只影响个别能力，断网时允许以降级模式继续启动。
$hardImports = @{ 'openpyxl' = '读取台账与资金占用费表' }
$softImports = @{
    'fitz'                 = 'PDF 文字提取（单据核查/回单解析）'
    'pypdf'                = 'PDF 回单文字提取'
    'rapidocr_onnxruntime' = '扫描件 OCR（仅「新增项目」上传扫描件时需要）'
    'docx'                 = '催款函 Word 生成'
}
$eapSaved2 = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$missingHard = @()
foreach ($module in $hardImports.Keys) {
    & $py @pyArgs -c "import $module" 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { $missingHard += $module }
}
$missingSoft = @()
foreach ($module in $softImports.Keys) {
    & $py @pyArgs -c "import $module" 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { $missingSoft += $module }
}
$ErrorActionPreference = $eapSaved2

if ($missingHard.Count -gt 0) {
    Write-Host "      缺少核心依赖：$($missingHard -join ', ')（读取台账必需）" -ForegroundColor Yellow
    & $py @pyArgs -m pip install -r (Join-Path $Root 'work_review\requirements.txt')
    $stillMissing = @()
    $eapSaved3 = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    foreach ($module in $missingHard) {
        & $py @pyArgs -c "import $module" 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) { $stillMissing += $module }
    }
    $ErrorActionPreference = $eapSaved3
    if ($stillMissing.Count -gt 0) {
        Write-Host '[错误] 核心依赖 openpyxl 安装失败，无法读取台账与资金占用费表。' -ForegroundColor Red
        Write-Host '       请检查网络，或手动执行：' -ForegroundColor Yellow
        Write-Host "       $py $($pyArgs -join ' ') -m pip install openpyxl" -ForegroundColor Yellow
        Read-Host '按回车键退出'; exit 1
    }
}

if ($missingSoft.Count -gt 0) {
    Write-Host "      检测到 $($missingSoft.Count) 项可选组件缺失，尝试自动安装（约 130 MB，需联网）……" -ForegroundColor DarkGray
    & $py @pyArgs -m pip install -r (Join-Path $Root 'work_review\requirements.txt')
    if ($LASTEXITCODE -ne 0) {
        Write-Host ''
        Write-Host '[提示] 可选组件未安装成功，将以「降级模式」启动。' -ForegroundColor Yellow
        Write-Host '       以下功能会受影响：' -ForegroundColor Yellow
        foreach ($module in $missingSoft) {
            Write-Host "         · $($softImports[$module])" -ForegroundColor DarkGray
        }
        Write-Host '       看板 / 结算核算 / 资金占用费 / 逾期统计 / 智能问答（本地规则）均正常可用。' -ForegroundColor Green
        $env:CONTROL_TOWER_DEGRADED = '1'
        Write-Host ''
    } else {
        Write-Host '      可选组件已安装。' -ForegroundColor Green
    }
}

# ---------- 2.6 Ollama 能力提示 ----------
try {
    $ollama = Invoke-WebRequest -Uri 'http://127.0.0.1:11434/api/tags' -UseBasicParsing -TimeoutSec 3 -ErrorAction Stop
    Write-Host '      本地模型服务(Ollama) 已就绪' -ForegroundColor Green
} catch {
    Write-Host '      未检测到 Ollama：合同向量检索、经营体检报告与自由问答会降级为本地规则；看板、OCR、新增项目、结算核算与固定演示不受影响。' -ForegroundColor Yellow
    Write-Host '      需要完整效果请安装 https://ollama.com 并执行 ollama pull bge-m3 与 ollama pull qwen2.5:1.5b' -ForegroundColor DarkYellow
}

# ---------- 3. 端口检查 ----------
$conn = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($conn) {
    $oldPids = @($conn.OwningProcess | Select-Object -Unique)
    Write-Host ''
    Write-Host "[3/5] 端口 $Port 已被占用 (PID: $($oldPids -join ', '))" -ForegroundColor Yellow
    Write-Host '      这通常是上一轮的旧实例，它加载的是旧代码。' -ForegroundColor DarkGray
    $ans = (Read-Host '      关掉旧的、用最新代码重新启动? [回车=是 / n=不]').Trim()
    if ($ans -eq 'n' -or $ans -eq 'N') {
        Write-Host '      保持旧实例不动，直接打开浏览器。' -ForegroundColor Cyan
        Start-Process "http://127.0.0.1:$Port"
        exit 0
    }
    foreach ($p in $oldPids) {
        Stop-Process -Id $p -Force -ErrorAction SilentlyContinue
    }
    Write-Host '      旧实例已停止。' -ForegroundColor Green
    Start-Sleep -Seconds 2
} else {
    Write-Host "[3/5] 端口 $Port 空闲" -ForegroundColor DarkGray
}

# ---------- 4. 启动服务 ----------
$env:DEEPSEEK_API_KEY = $key
$env:MODEL_PROVIDER    = if ($key) { 'deepseek' } else { 'ollama' }
$env:DATASET_ROOT     = Join-Path $Root 'A项目-演示资料'
$env:PORT              = "$Port"

Write-Host ''
Write-Host "[4/5] 正在启动服务..." -ForegroundColor Cyan
try {
    $proc = Start-Process -FilePath $py `
                          -ArgumentList ($pyArgs + @('work_review/server.py')) `
                          -WorkingDirectory $Root `
                          -WindowStyle Minimized `
                          -PassThru
} catch {
    Write-Host "[错误] 启动失败: $($_.Exception.Message)" -ForegroundColor Red
    Read-Host '按回车键退出'
    exit 1
}
Start-Sleep -Seconds 2
if ($proc.HasExited) {
    Write-Host '[错误] 服务进程启动后立即退出了。' -ForegroundColor Red
    Write-Host '       常见原因：端口被占、依赖缺失。请截图这个窗口给技术同事。' -ForegroundColor DarkGray
    Read-Host '按回车键退出'
    exit 1
}
Write-Host "      已启动，PID = $($proc.Id)" -ForegroundColor Green

# ---------- 5. 等待就绪 ----------
Write-Host ''
Write-Host "[5/5] 等待服务就绪" -NoNewline
$ready = $false
for ($i = 0; $i -lt 40; $i++) {
    Start-Sleep -Seconds 1
    Write-Host '.' -NoNewline
    try {
        $r = Invoke-WebRequest -Uri "http://127.0.0.1:$Port/api/dashboard?project_id=demo_a" `
                               -UseBasicParsing -TimeoutSec 3 -ErrorAction Stop
        if ($r.StatusCode -eq 200) { $ready = $true; break }
    } catch { }
}
Write-Host ''

if (-not $ready) {
    Write-Host '[警告] 等了 40 秒还没响应，服务可能启动异常。' -ForegroundColor Red
    Write-Host ''
    Read-Host '按回车键退出'
    exit 1
}

# 模型提供方
try {
    $info = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/status" -TimeoutSec 5 -ErrorAction Stop
    if ($info.model_provider) {
        Write-Host "      模型提供方: $($info.model_provider)" -ForegroundColor Green
    }
} catch {
    Write-Host "      模型提供方: $env:MODEL_PROVIDER (按环境变量设置)" -ForegroundColor Green
}

Write-Host ''
Write-Host '========================================' -ForegroundColor Cyan
Write-Host "   启动完成   http://127.0.0.1:$Port" -ForegroundColor Cyan
Write-Host '========================================' -ForegroundColor Cyan
Write-Host ''
Write-Host '服务运行在最小化窗口里 —— 关掉那个黑色窗口就等于停止服务。' -ForegroundColor DarkGray
Write-Host '浏览器马上自动打开...' -ForegroundColor DarkGray
Write-Host ''

Start-Process "http://127.0.0.1:$Port"
Start-Sleep -Seconds 3
