"""停止本目录启动的服务（按端口找进程，不误杀别的 python）。"""
import subprocess
import sys

PORT = 8927


def say(m=""):
    print(m, flush=True)


def pause():
    """双击运行时等回车；被脚本调用（无输入设备）时直接返回。"""
    try:
        input("按回车退出...")
    except EOFError:
        pass


say(f"正在查找占用 {PORT} 端口的服务 ...")
try:
    out = subprocess.run(
        ["netstat", "-ano", "-p", "TCP"], capture_output=True, text=True, errors="ignore"
    ).stdout
except Exception as e:
    say(f"[错误] 无法执行 netstat：{e}")
    pause()
    sys.exit(1)

pids = set()
for line in out.splitlines():
    parts = line.split()
    if len(parts) >= 5 and parts[1].endswith(f":{PORT}") and parts[3] == "LISTENING":
        pids.add(parts[4])

if not pids:
    say(f"没有在 {PORT} 端口发现服务，可能已经停了。")
    pause()
    sys.exit(0)

for pid in sorted(pids):
    if not pid.isdigit():
        continue
    r = subprocess.run(["taskkill", "/PID", pid, "/F"], capture_output=True, text=True, errors="ignore")
    if r.returncode == 0:
        say(f"  已停止 PID={pid}")
    else:
        say(f"  停止 PID={pid} 失败：{(r.stderr or r.stdout).strip()[:100]}")

say()
say("服务已停止，浏览器页面可以关掉了。")
pause()
